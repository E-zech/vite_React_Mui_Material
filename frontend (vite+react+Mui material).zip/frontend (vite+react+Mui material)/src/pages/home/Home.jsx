import React, { useContext, useEffect } from 'react';
// import { GeneralContext } from '../../App';

export default function Home() {
    // const { msg, setMsg } = useContext(GeneralContext);
    return (
        <>
            <section>
                <div>
                    <h1>Welcome to the home page</h1>
                    {/* <h2>{msg}</h2> */}
                    <br />
                    <button className='btn-custom'>Button</button>
                </div>
            </section>
        </>
    );
} 