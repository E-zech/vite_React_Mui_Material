import React, { useState, useEffect } from 'react';
import {
    Avatar,
    Button,
    TextField,
    Grid,
    Box,
    Typography,
    Container,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';

export default function Account() {
    const navigate = useNavigate();

    // סטייט לטופס עריכת פרטים עם השדות הדרושים
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        phone: '',
        email: '',
        city: '',
        street: '',
        houseNumber: '',
        zip: '',
        imgSrc: '',
        imgAlt: '',
    });

    // ניהול שגיאות (ניתן להרחיב לפי צורך)
    const [errors, setErrors] = useState({});
    // סטייט האם הטופס תקין – כאן לדוגמה תמיד תקין
    const [isFormValid, setIsFormValid] = useState(true);
    // סטייט למשתמש – בדוגמה זו נטען משתמש מדומה (במקום להשתמש ב-context)
    const [user, setUser] = useState(null);

    // בהדמיית טעינת המשתמש, נעדכן את הטופס עם נתוני המשתמש
    useEffect(() => {
        // כאן ניתן להחליף בקריאה ל-API לטעינת המשתמש
        const fetchedUser = {
            _id: '123',
            firstName: 'John',
            lastName: 'Doe',
            phone: '1234567890',
            email: 'john.doe@example.com',
            city: 'Tel Aviv',
            street: 'Herzl',
            houseNumber: '10',
            zip: '61000',
            imgSrc: 'https://via.placeholder.com/150',
            imgAlt: 'User Avatar',
        };
        setUser(fetchedUser);
        setFormData({
            firstName: fetchedUser.firstName,
            lastName: fetchedUser.lastName,
            phone: fetchedUser.phone,
            email: fetchedUser.email,
            city: fetchedUser.city,
            street: fetchedUser.street,
            houseNumber: fetchedUser.houseNumber,
            zip: fetchedUser.zip,
            imgSrc: fetchedUser.imgSrc,
            imgAlt: fetchedUser.imgAlt,
        });
    }, []);

    // עדכון שדות הטופס
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    // שליחת הטופס לעדכון המשתמש
    const handleSubmit = (e) => {
        e.preventDefault();
        // קריאה ל-API לעדכון המשתמש – החלף את הכתובת בהתאם
        fetch(`http://localhost:5000/users/${user._id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData),
        })
            .then((res) => {
                if (!res.ok) {
                    throw new Error('Network response was not ok');
                }
                return res.json();
            })
            .then((data) => {
                // עדכון המשתמש במידה והעדכון עבר בהצלחה
                setUser(data);
                alert('User details updated successfully');
                navigate('/');
            })
            .catch((error) => {
                console.error('Error updating user:', error);
                alert('Error updating user');
            });
    };

    // במידה והמשתמש עדיין לא נטען – אפשר להציג מסך טעינה או להחזיר null
    if (!user) return null;

    return (
        <Container component="main" maxWidth="xs">
            <Box
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}
            >
                <Avatar
                    src={user.imgSrc}
                    alt={user.imgAlt || 'User Avatar'}
                    sx={{ width: 80, height: 80, mb: 2 }}
                />
                <Typography component="h1" variant="h5">
                    Edit Details
                </Typography>
                <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
                    <Grid container spacing={2}>
                        {/* First Name */}
                        <Grid item xs={12} sm={6}>
                            <TextField
                                name="firstName"
                                required
                                fullWidth
                                label="First Name"
                                value={formData.firstName}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                        {/* Last Name */}
                        <Grid item xs={12} sm={6}>
                            <TextField
                                name="lastName"
                                required
                                fullWidth
                                label="Last Name"
                                value={formData.lastName}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                        {/* Email */}
                        <Grid item xs={12}>
                            <TextField
                                name="email"
                                required
                                fullWidth
                                label="Email"
                                value={formData.email}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                        {/* Phone */}
                        <Grid item xs={12}>
                            <TextField
                                name="phone"
                                fullWidth
                                label="Phone"
                                value={formData.phone}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                        {/* City */}
                        <Grid item xs={12}>
                            <TextField
                                name="city"
                                fullWidth
                                label="City"
                                value={formData.city}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                        {/* Street */}
                        <Grid item xs={12}>
                            <TextField
                                name="street"
                                fullWidth
                                label="Street"
                                value={formData.street}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                        {/* House Number */}
                        <Grid item xs={6}>
                            <TextField
                                name="houseNumber"
                                fullWidth
                                label="House Number"
                                value={formData.houseNumber}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                        {/* ZIP Code */}
                        <Grid item xs={6}>
                            <TextField
                                name="zip"
                                fullWidth
                                label="ZIP Code"
                                value={formData.zip}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                        {/* Image URL */}
                        <Grid item xs={12}>
                            <TextField
                                name="imgSrc"
                                fullWidth
                                label="Image URL"
                                value={formData.imgSrc}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                        {/* Image Alt */}
                        <Grid item xs={12}>
                            <TextField
                                name="imgAlt"
                                fullWidth
                                label="Image Alt Text"
                                value={formData.imgAlt}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                    </Grid>
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        disabled={!isFormValid}
                        sx={{ mt: 3, mb: 2 }}
                    >
                        Save
                    </Button>
                </Box>
            </Box>
        </Container>
    );
}
