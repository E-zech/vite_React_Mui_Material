import { Route, Routes } from 'react-router-dom';
import Home from './pages/home/Home.jsx';
import Signup from './auth/signup/Signup.jsx';
import Login from './auth/login/Login.jsx';
import Account from './auth/account/Account.jsx';
export default function Router() {
    return (
        <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/account" element={<Account />} />
        </Routes>
    )
}