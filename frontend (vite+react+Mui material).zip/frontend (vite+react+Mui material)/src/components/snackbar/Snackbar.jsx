import './Snackbar.css';

export default function Snackbar({ text }) {
    return (
        <div id='snackbar'>{text}</div>
    )
}