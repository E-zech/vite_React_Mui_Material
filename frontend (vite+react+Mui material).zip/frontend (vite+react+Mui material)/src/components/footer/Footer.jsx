import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { GeneralContext } from '../../App';
import './Footer.css';
import { FaFacebook, FaInstagram, FaLinkedin, FaTiktok, FaTwitter } from 'react-icons/fa';

export default function Footer() {
    const navigate = useNavigate();
    const { mode } = useContext(GeneralContext);

    // ניתן להחליף צבעים אלה לפי ההגדרות שלך או לייבא משתנים מחבילת סגנונות
    const backgroundColor = mode === 'dark' ? '#000' : '#1976d2';

    // סגנונות בסיסיים ללוגו
    const logoImgStyle = {
        width: '50px',
        height: '50px',
        filter: mode === 'dark' ? 'hue-rotate(30deg) brightness(191%)' : 'grayscale(90%)',
        cursor: 'pointer',
    };

    const logoSpanStyle = {
        position: 'absolute',
        marginTop: '23px',
        color: mode === 'dark' ? 'white' : 'black',
        fontFamily: 'Arial, sans-serif',
        cursor: 'pointer',
    };

    return (
        <footer className="footer" style={{ backgroundColor }}>
            <section className="footerTop">
                <div className="footerLogo" onClick={() => navigate('/')}>
                    <img
                        src="https://png.pngtree.com/png-vector/20221012/ourmid/pngtree-skincare-logo-png-image_6309022.png"
                        alt="Logo"
                        style={logoImgStyle}
                    />
                    <span style={logoSpanStyle}>S</span>
                </div>
                <div className="footerAboutBtn" onClick={() => navigate('/about')}>
                    About Us
                </div>
                <div>Phone: 050-12345678</div>
                <div>Email: skinCare@gmail.com</div>
            </section>

            <hr className="footerHr" />

            <section className="footerBottom">
                <div className="footer-icons">
                    <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
                        <FaFacebook />
                    </a>
                    <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
                        <FaInstagram />
                    </a>
                    <a href="https://www.tiktok.com" target="_blank" rel="noopener noreferrer">
                        <FaTiktok />
                    </a>
                    <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
                        <FaTwitter />
                    </a>
                    <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
                        <FaLinkedin />
                    </a>
                </div>

                <div>&copy; All Rights Reserved E.Z</div>
            </section>
        </footer>
    );
}
