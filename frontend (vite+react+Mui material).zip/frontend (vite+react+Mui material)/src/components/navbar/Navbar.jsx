import React, { useState } from 'react';
import { AppBar, Box, Toolbar, IconButton, Typography, Menu, Container, Button, Tooltip, MenuItem } from '@mui/material';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import MenuIcon from '@mui/icons-material/Menu';
import Brightness4Icon from '@mui/icons-material/Brightness4';
import NightlightIcon from '@mui/icons-material/Nightlight';

// דוגמה למערך דפים, ניתן להרחיב או לשנות לפי הצורך
const pages = [
    { title: 'Home', route: '/' },
    { title: 'Login', route: '/login' },
    { title: 'Signup', route: '/signup' },
    { title: 'Account', route: '/account' },
];

export default function Navbar() {
    const [anchorElNav, setAnchorElNav] = useState(null);
    const [darkMode, setDarkMode] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();

    const handleOpenNavMenu = (event) => {
        setAnchorElNav(event.currentTarget);
    };

    const handleCloseNavMenu = () => {
        setAnchorElNav(null);
    };

    return (
        <AppBar position="static" sx={{ backgroundColor: darkMode ? '#333' : '#1976d2' }}>
            <Container maxWidth="xl">
                <Toolbar disableGutters>
                    {/* לוגו עבור דסקטופ */}
                    <Typography
                        variant="h6"
                        noWrap
                        component="div"
                        sx={{
                            mr: 2,
                            display: { xs: 'none', md: 'flex' },
                            cursor: 'pointer',
                        }}
                        onClick={() => navigate('/')}
                    >
                        LOGO
                    </Typography>

                    {/* תפריט מובייל */}
                    <Box sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' } }}>
                        <IconButton size="large" onClick={handleOpenNavMenu} color="inherit">
                            <MenuIcon />
                        </IconButton>
                        <Menu
                            anchorEl={anchorElNav}
                            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
                            keepMounted
                            transformOrigin={{ vertical: 'top', horizontal: 'left' }}
                            open={Boolean(anchorElNav)}
                            onClose={handleCloseNavMenu}
                            sx={{ display: { xs: 'block', md: 'none' } }}
                        >
                            {pages.map((page) => (
                                <MenuItem
                                    key={page.title}
                                    onClick={() => {
                                        handleCloseNavMenu();
                                        navigate(page.route);
                                    }}
                                >
                                    <Typography textAlign="center">{page.title}</Typography>
                                </MenuItem>
                            ))}
                        </Menu>
                    </Box>

                    {/* לוגו עבור מובייל */}
                    <Typography
                        variant="h6"
                        noWrap
                        component="div"
                        sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' }, cursor: 'pointer' }}
                        onClick={() => navigate('/')}
                    >
                        LOGO
                    </Typography>

                    {/* תפריט דסקטופ */}
                    <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
                        {pages.map((page) => (
                            <Button
                                key={page.title}
                                onClick={() => navigate(page.route)}
                                sx={{
                                    my: 2,
                                    color: 'white',
                                    display: 'block',
                                }}
                            >
                                {page.title}
                            </Button>
                        ))}
                    </Box>

                    {/* לחצן לעבור מצב לייט/דארק */}
                    <Box sx={{ flexGrow: 0 }}>
                        <Tooltip title={darkMode ? 'Light Mode' : 'Dark Mode'}>
                            <IconButton onClick={() => setDarkMode(!darkMode)} color="inherit">
                                {darkMode ? <Brightness4Icon /> : <NightlightIcon />}
                            </IconButton>
                        </Tooltip>
                    </Box>
                </Toolbar>
            </Container>
        </AppBar>
    );
}
