import { useState, createContext, useEffect } from 'react';
import './App.css'
import './ScrollBar.css';

// import { ThemeProvider, createTheme } from '@mui/material/styles';
import Router from './Router.jsx';
import Navbar from './components/navbar/Navbar.jsx';

export const GeneralContext = createContext();

function App() {
  const [msg, setMsg] = useState('HELLO WORLD');
  return (
    <>
      <GeneralContext.Provider value={{ msg, setMsg }}>
        <Navbar />
        <Router />
      </GeneralContext.Provider>
    </>
  )
}
export default App