import React, { useContext, useEffect } from 'react';
import './Home.css'

export default function Home() {
    return (
        <>
            <header className='header'>
                <h1>Welcome to the home page</h1>
            </header>
        </>
    );
} 