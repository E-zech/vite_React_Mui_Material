import React, { useState, useEffect } from 'react';
import { Avatar, Button, TextField, Grid, Box, Typography, Container, } from '@mui/material';
import { useNavigate } from 'react-router-dom';

export default function Account() {
    const navigate = useNavigate();
    const [user, setUser] = useState(null);
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
    });

    useEffect(() => {
        const fetchedUser = {
            _id: '123',
            firstName: 'John',
            lastName: 'Doe',
            email: 'john.doe@example.com',
        };
        setUser(fetchedUser);
        setFormData(fetchedUser);
    }, []);


    const fields = [
        { name: 'firstName', label: 'First Name', required: true, grid: { xs: 12, sm: 6 } },
        { name: 'lastName', label: 'Last Name', required: true, grid: { xs: 12, sm: 6 } },
        { name: 'email', label: 'Email', required: true, grid: { xs: 12 } },
    ];

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        fetch(`http://localhost:5000/users/${user._id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData),
        })
            .then((res) => {
                if (!res.ok) throw new Error('Network response was not ok');
                return res.json();
            })
            .then((data) => {
                setUser(data);
                alert('User details updated successfully');
                navigate('/');
            })
            .catch((error) => {
                console.error('Error updating user:', error);
                alert('Error updating user');
            });
    };

    if (!user) return null;

    return (
        <Container component="main" maxWidth="xs">
            <Box
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}
            >
                <Avatar sx={{ m: 1, width: 80, height: 80 }}>
                    {formData.firstName.charAt(0)}
                </Avatar>
                <Typography component="h1" variant="h5">
                    Edit Details
                </Typography>
                <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
                    <Grid container spacing={2}>
                        {fields.map(({ name, label, required, grid }) => (
                            <Grid key={name} item {...grid}>
                                <TextField
                                    name={name}
                                    required={required}
                                    fullWidth
                                    label={label}
                                    value={formData[name]}
                                    onChange={handleChange}
                                    InputLabelProps={{ shrink: true }}
                                />
                            </Grid>
                        ))}
                    </Grid>
                    <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2 }}>
                        Save
                    </Button>
                </Box>
            </Box>
        </Container>
    );
}
