import React, { useState } from 'react';
import { Avatar, Button, TextField, Grid, Box, Typography, Container, } from '@mui/material';
import AssignmentIndIcon from '@mui/icons-material/AssignmentInd';
import { useNavigate } from 'react-router-dom';

export default function Signup() {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
    });

    const fields = [
        {
            name: 'firstName',
            label: 'First Name',
            required: true,
            grid: { xs: 12, sm: 6 },
            autoFocus: true,
            type: 'text',
        },
        {
            name: 'lastName',
            label: 'Last Name',
            required: true,
            grid: { xs: 12, sm: 6 },
            type: 'text',
        },
        {
            name: 'email',
            label: 'Email Address',
            required: true,
            grid: { xs: 12 },
            type: 'email',
        },
        {
            name: 'password',
            label: 'Password',
            required: true,
            grid: { xs: 12 },
            type: 'password',
        },
    ];

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        navigate('/login');
    };

    return (
        <Container component="main" maxWidth="xs">
            <Box
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}
            >
                <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
                    <AssignmentIndIcon />
                </Avatar>
                <Typography component="h1" variant="h5">
                    Sign Up
                </Typography>
                <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 3 }}>
                    <Grid container spacing={2}>
                        {fields.map((field) => (
                            <Grid key={field.name} item {...field.grid}>
                                <TextField
                                    name={field.name}
                                    required={field.required}
                                    fullWidth
                                    label={field.label}
                                    type={field.type}
                                    value={formData[field.name]}
                                    onChange={handleChange}
                                    autoFocus={field.autoFocus || false}
                                />
                            </Grid>
                        ))}
                    </Grid>
                    <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2 }}>
                        Sign Up
                    </Button>
                    <Grid container justifyContent="center">
                        <Grid item>
                            <Button variant="text" onClick={() => navigate('/login')}>
                                Already have an account? Log in
                            </Button>
                        </Grid>
                    </Grid>
                </Box>
            </Box>
        </Container>
    );
}
